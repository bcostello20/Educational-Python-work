# -*- coding: utf-8 -*-
"""
Created on Sat Oct  5 16:17:23 2019

GuessingGame_Costello.py

This script plays "guess the number" game. It choses a number to be guessed by the user in a range of--
1 to 1000. It will tell the user whether they guessed too high, too low, or they won the game.
Lastly, it will ask the user if they want to play again if they have won.

@author: Benjamin Costello
"""
import random

def randomNumber():
    """Generates a random number in the range of 1 to 1000."""
    number = random.randrange(1, 1001)
    return number

def hint(guess):
    """Detemines which hint to display to the user based on their guess."""
    if guess > theNumber:
        print("Too high. Try again.")
    elif guess < theNumber:
        print("Too low. Try again.")   

#Set playAgain to 'y' so the following while loop runs.
playAgain = 'y'

while (playAgain == 'y' or playAgain == 'Y'):
    #Get the number guess from the user
    guess = int(input("Guess my number between 1 and 1000 with the fewest guesses: "))
    
    #Set a new variable 'theNumber' equal to randomNumber function return value.
    theNumber = randomNumber()
    
    #While the user's guess does not equal the random number let the user know why and ask again.
    while (guess != theNumber):
        displayHint = hint(guess)
        guess = int(input("Guess my number between 1 and 1000 with the fewest guesses: "))

    #If the user's guess does equal the random number let the user know they won.
    print("Congratulations. You guessed the number!")
    playAgain = input("Would you like to play again? (y/n): ")

#Tell the user the game has ended if they have chosen not to continue playing.
print("Game has ended.")