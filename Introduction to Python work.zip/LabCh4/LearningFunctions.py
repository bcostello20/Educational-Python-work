# -*- coding: utf-8 -*-
"""
Created on Fri Oct  4 10:26:05 2019

Chapter4A Lab - Functions Intro

LearningFunctions.py

Lab4A: We write several basic functions in this lab.

@author: Benjamin Costello
"""

def findLetterGrade(score):
    """Determines the letter grade for any given numeric grade."""
    if score >= 90:
        return 'A'
    elif score >= 80:
        return 'B'
    elif score >= 70:
        return 'C'
    elif score >= 60:
        return 'D'
    else:
        return 'F'
print(findLetterGrade(95))
print(findLetterGrade(75))
print(findLetterGrade(52))

#------------------------------------------------------------------------------

def calculateStadiumSales(classA, classB, classC):
    """Detemines how many class seats of each type were sold."""
    totalIncome = (classA * 20) + (classB * 15) + (classC * 10)
    return totalIncome

aSeats = int(input("Enter how many class A seats were sold: "))
bSeats = int(input("Enter how many class B seats were sold: "))
cSeats = int(input("Enter how many class C seats were sold: "))

total = calculateStadiumSales(aSeats, bSeats, cSeats)
print("A:", aSeats)
print("B:", bSeats)
print("C:", cSeats)
print("Total Income: $", total, sep="")