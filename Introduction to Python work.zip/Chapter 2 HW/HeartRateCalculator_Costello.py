# -*- coding: utf-8 -*-
"""
Created on Fri Aug 30 11:48:19 2019

@author: Benjamin Costello
"""

#Get the user's age
age = int(input("Enter your age: "))

#Get user's max heart rate
maxHeartRate = 220 - age
print("Your maximum heart rate is: " , maxHeartRate)

#***User's target heart rate range***#

#Get user's maximum target heart rate
maxTargetRate = maxHeartRate * 0.85
print("Your maximum target heart rate is: " , maxTargetRate)

#Get user's minimum target heart rate
minTargetRate = maxHeartRate * 0.50
print("Your minimum target heart rate is: " , minTargetRate)