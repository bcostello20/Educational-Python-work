# -*- coding: utf-8 -*-
"""
Created on Wed Nov  6 09:59:40 2019

Lab5D_ComplexLists_Costello.py

This script focuses on Chapter5D Lab with a focus on Complex List Manipulations.

@author: Benjamin Costello
"""

students = [("Karen", "Sophomore"), ("Pranshu", "Junior"), ("Ann", "Senior"),

        ("Carl", "Freshmen"), ("Cait", "Freshmen"), ("Kathleen", "Sophomore")]

upperClassmen = [student[0] for student in students if student[1] == "Junior" or
                 student[1] == "Senior"]

print(upperClassmen)

aList = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

firstSum = sum(map(lambda n: n * 3, 
        filter(lambda n: n % 2 == 0, aList)))

print("The first sum is:", firstSum)

secondSum = sum([num * 3 for num in aList if num % 2 == 0])

print("The second sum is:", secondSum)

numbers = [10, 3, 7, 1, 9, 4, 2, 8, 5, 6]

l = list(map(lambda x: x * 2,
             filter(lambda x: x % 2 == 0, numbers)))

print(l)

l = list(filter(lambda x: x % 2 == 0,
                map(lambda x: x * 2, numbers)))

print(l)