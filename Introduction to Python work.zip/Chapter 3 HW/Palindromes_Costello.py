# -*- coding: utf-8 -*-
"""
Created on Wed Sep 11 11:37:17 2019

@author: Benjamin Costello

This is a script that reads in a five-digit integer and determines whether it's a palindrome.

"""

#Get the five-digit integer from the user.
theNumber = (input("Enter a five-digit integer: "))

#Check to see if it is a palindrome or not.
if theNumber == "".join(reversed(theNumber)):
    print("This number is a palindrome.")
else:
    print("This number is not a palindrome.")