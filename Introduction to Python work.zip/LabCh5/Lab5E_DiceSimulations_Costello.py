# -*- coding: utf-8 -*-
"""
Created on Fri Nov 22 10:01:00 2019

Lab5E_DiceSimulations_Costello.py

This script focuses on Lab5E which has a focus on Graphical Visualizations with
Die Simulations.

@author: Benjamin Costello
"""

import matplotlib.pyplot as plt

import numpy as np

import random

import seaborn as sns

def create_barchart(results, atitle, atitle2, atitle3):
    """Takes in a list, tile, a title for the x-axis and a title for the y-axis."""
    
    values, frequencies = np.unique(results, return_counts=True)
    
    sns.set_style("whitegrid")
    
    axes = sns.barplot(x=values, y=frequencies, palette="bright")
    
    axes.set_title(atitle)
    
    axes.set(xlabel= xTitle, ylabel= yTitle)  
    
    axes.set_ylim(top=max(frequencies) * 1.10)
    
    for bar, frequency in zip(axes.patches, frequencies):
        text_x = bar.get_x() + bar.get_width() / 2.0
        text_y = bar.get_height()
        text = f"{frequency:,}\n{frequency / len(results):.3%}"
        axes.text(text_x, text_y, text,
                  fontsize=11, ha="center", va="bottom")

#Questions 3 bullet point 1
#rolls = [random.randrange(1, 7) for i in range(600)]
        
results = []
for j in range(0, 1_000_000): #Number of trials
    count1s = 0
    #below is 1 trial
    for i in range (1, 5):
        die = random.randrange(1, 7)
        if die == 1:
            count1s = count1s + 1
    results.append(count1s)

#print(results)

#title = f"Rolling a Six-Sided Die {len(results):,} Times"
#xTitle = f"Number of 1's in a {len(results):,} trials"
#yTitle = "Frequency"
     
#create_barchart(results, title, xTitle, yTitle)

#Question 3 bullet point 2

#results2 = []



#for j in range(0, 1_000_000): #Number of trials
#    count1s = 0
#    #below is 1 trial
#    for i in range (1, 25):
#        die = random.randrange(1, 7)
#        die2 = random.randrange(1, 7)
#        if die == 1 and die2 == 1:
#            count1s = count1s + 1
#    results2.append(count1s)
    
#title = f"Rolling a Six-Sided Die {len(results2):,} Times"
#xTitle = f"Number of snake eyes in a {len(results2):,} trials"
#yTitle = "Frequency"
    
#create_barchart(results2, title, xTitle, yTitle)

#Question 3 bullet point 3

#results3 = []
#
#for j in range(0, 1000): #Number of trials
#    count1s = 0
#    #below is 1 trial
#    for i in range (3, 8):
#        die = random.randrange(1, 7)
#        die2 = random.randrange(1, 7)
#        total = die + die2
#        if total != 7:
#            count1s = count1s + 1
#    results3.append(count1s)
#    
#title = f"Rolling a Six-Sided Die {len(results3):,} Times"
#xTitle = f"Number of 4's before getting a 7 in a {len(results3):,} trials"
#yTitle = "Frequency"
#    
#create_barchart(results3, title, xTitle, yTitle)
    
#results4 = []
#
#for j in range(0, 1000): #Number of trials
#    count1s = 0
#    #below is 1 trial
#    for i in range (3, 8):
#        die = random.randrange(1, 7)
#        die2 = random.randrange(1, 7)
#        total = die + die2
#        if total != 7:
#            count1s = count1s + 1
#    results4.append(count1s)
#    
#title = f"Rolling a Six-Sided Die {len(results4):,} Times"
#xTitle = f"Number of 5's before getting a 7 in a {len(results4):,} trials"
#yTitle = "Frequency"
#    
#create_barchart(results4, title, xTitle, yTitle)
    
#results5 = []
#
#for j in range(0, 1000): #Number of trials
#    count1s = 0
#    #below is 1 trial
#    for i in range (2, 8):
#        die = random.randrange(1, 7)
#        die2 = random.randrange(1, 7)
#        total = die + die2
#        if total != 7:
#            count1s = count1s + 1
#    results5.append(count1s)
#    
#title = f"Rolling a Six-Sided Die {len(results5):,} Times"
#xTitle = f"Number of 6's before getting a 7 in a {len(results5):,} trials"
#yTitle = "Frequency"
#    
#create_barchart(results5, title, xTitle, yTitle)
    
#results6 = []
#
#for j in range(0, 1000): #Number of trials
#    count1s = 0
#    #below is 1 trial
#    for i in range (0, 8):
#        die = random.randrange(1, 7)
#        die2 = random.randrange(1, 7)
#        total = die + die2
#        if total != 7:
#            count1s = count1s + 1
#    results6.append(count1s)
#    
#title = f"Rolling a Six-Sided Die {len(results6):,} Times"
#xTitle = f"Number of 8's before getting a 7 in a {len(results6):,} trials"
#yTitle = "Frequency"
#    
#create_barchart(results6, title, xTitle, yTitle)
    
#results7 = []
#
#for j in range(0, 1000): #Number of trials
#    count1s = 0
#    #below is 1 trial
#    for i in range (0, 9):
#        die = random.randrange(1, 7)
#        die2 = random.randrange(1, 7)
#        total = die + die2
#        if total != 7:
#            count1s = count1s + 1
#    results7.append(count1s)
#    
#title = f"Rolling a Six-Sided Die {len(results7):,} Times"
#xTitle = f"Number of 9's before getting a 7 in a {len(results7):,} trials"
#yTitle = "Frequency"
#    
#create_barchart(results7, title, xTitle, yTitle)
    
results8 = []

for j in range(0, 1000): #Number of trials
    count1s = 0
    #below is 1 trial
    for i in range (0, 10):
        die = random.randrange(1, 7)
        die2 = random.randrange(1, 7)
        total = die + die2
        if total != 7:
            count1s = count1s + 1
    results8.append(count1s)
    
title = f"Rolling a Six-Sided Die {len(results8):,} Times"
xTitle = f"Number of 10's before getting a 7 in a {len(results8):,} trials"
yTitle = "Frequency"
    
create_barchart(results8, title, xTitle, yTitle)