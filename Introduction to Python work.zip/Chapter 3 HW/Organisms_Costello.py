# -*- coding: utf-8 -*-
"""
Created on Tue Sep 24 15:53:50 2019

HW 3D (2 of 2): NON TEXTBOOK PROBLEM

This script will ask the user to enter the starting number of organisms,
the average daily population increase (as a percentage), and the number of days the organisms will be left to--
multiply. It will print the results as a table, using both a for and a while loop separately.

@author: Benjamin Costello
"""

#Get inputs from the user
startingOrganisms = int(input("Enter starting number of organisms: "))
populationIncrease = float(input("Enter average daily population increase (%): "))
days = int(input("Enter number of days the organisms will be left to multiply: "))
print()

#Using a for loop
population = startingOrganisms
print ("Day Approximate\tPopulation") #Table header
print("1","\t","\t", population)
        
for day in range(2, days + 1):
    population *= (1 + populationIncrease / 100)
    print(day,"\t","\t", population)
    
    
    
#Using a while loop
print()
theDay = 2
thePopulation = startingOrganisms
print ("Day Approximate\tPopulation") #Table header
print("1","\t","\t", thePopulation)
while (theDay < days + 1):
    thePopulation *= (1 + populationIncrease / 100)
    print(theDay,"\t","\t", thePopulation)
    theDay += 1
