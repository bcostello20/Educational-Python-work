# -*- coding: utf-8 -*-
"""
Created on Mon Nov  4 10:36:52 2019

Lab5C_MoreOnLists_Costello.py

This script focuses on Chatper5C Lab with a focus on More On Strings.

@author: Benjamin Costello
"""

def deleteDuplicates(numbers):
    """This function all duplicates from numbers and returns a sorted list of the
    unique values."""
    
    numbersCopy = sorted(numbers) #Create a sorted copy of numbers
    
    for num in numbers:
        #If the count of numbers is more than 1
        if (numbersCopy.count(num) > 1):
            #Determine the number of occurrences of num in numbersCopy
            occurrences = numbersCopy.count(num)
            
            #Also, determine the first occurrence of num in numbersCopy
            first = numbersCopy.index(num)
            
            #Delete all but 1 using slicing
            del numbersCopy[first+1:first + occurrences]
    return numbersCopy

def is_ordered(sequence):
    """This function receives a sequence and returns True if the elements
    are in sorted order."""
    
    sequenceCopy = sorted(sequence)
    
    if sequenceCopy == sequence:
        return True
    else:
        return False
    
l = [5, 3, 2, 1, 1, 1, 4, 5, 4, 6, 2, 2, 2]
print(deleteDuplicates(l))

print(is_ordered("acd"))
print(is_ordered([2, 5, 1, 3, 7, 4, 8, 10, 9, 6]))
print(is_ordered(["efg"]))
print(is_ordered([11, 12, 13, 14]))