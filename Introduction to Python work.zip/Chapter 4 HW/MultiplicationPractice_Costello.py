# -*- coding: utf-8 -*-
"""
Created on Mon Oct 21 11:55:12 2019

MultiplicationPractice_Costello.py

This script will help an elementary school student learn multiplication. It contains a--
function that randomly generates and turns a tuple of two positive one-digit integers.
It will prompt the user with a question such as "How much is 6 times 7? It will either--
display "Very good!" and ask another question or display "No. Please try again." and let--
the student try the same question repeatedly until the student gives the correct answer.

@author: Benjamin Costello
"""

import random

def mathProblem():
    """Randomly generates and returns a tuple of two positive one-digit integers."""
    #Generate the two numbers between 1 and 9.
    ranNum1 = random.randrange(1, 9)
    ranNum2 = random.randrange(1, 9)
    return ranNum1, ranNum2

ranNum1, ranNum2 = mathProblem()

#Set a boolean variable to test if the program should ask another question based on user input.
askAgain = True
  
#Asks the first question since askAgain starts as True.
#Will go through and ask a different question if the previous answer given was correct.  
while(askAgain == True):
    ranNum1, ranNum2 = mathProblem()
    message = "How much is " + str(ranNum1) + " times " + str(ranNum2) + "? "
    question = int(input(message))
    if question == ranNum1 * ranNum2:
        print("Very good!")
        playAgain = input("Play again?: ")
        if playAgain == 'y' or playAgain == 'Y':
            askAgain = True
            print()
        else:
            print("Program has ended.")
            break

#If the student gives a wrong answer it will ask them the same question again.
#It will continue to ask the same question until the student answers correctly.
    while(question != ranNum1 * ranNum2):
        askAgain = False
        print("No. Please try again.")
        print()
        message = "How much is " + str(ranNum1) + " times " + str(ranNum2) + "? "
        question = int(input(message))
        if question == ranNum1 * ranNum2:
            print("Very good!")
            playAgain = input("Play again?: ")
        if playAgain == 'y' or playAgain == 'Y':
            askAgain = True
            print()
        else:
            print("Program has ended.")
            break