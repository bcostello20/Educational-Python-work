# -*- coding: utf-8 -*-
"""
Created on Fri Oct 11 10:06:05 2019

Lab4C.py

This script covers all the work in Chapter4CLab. The topics are Tuples, Arbitrary Argument Lists,--
and Returning Multiple Values.

@author: Benjamin Costello
"""

import statistics

def average(*args):
    """Finds the average of an arbitrary number of values."""
    theAverage = sum(args) / len(args)
    return theAverage

def product(*args):
    """Finds the product of an arbitrary number of values."""
    theProduct = 1
    for num in(args):
     theProduct *= num
    return theProduct

def getNames():
    """Requests a first and last name and returns it."""
    first = input("What is your first name? ")
    middle = input("What is your middle name? ")
    last = input("What is your last name? ")
    return (first, middle, last)
    
def getMyStats(*args):
    """Finds the min, max, and median of the list and returns these values."""
    tuple1 = args
    minimum = min(args)
    maximum = max(args)
    mean = statistics.mean(args)
    median = statistics.median(args)
    return (minimum, maximum, mean, median, tuple1)

#Section 1 - TUPLES
x = 10
tuple1 = (2, "hi", x)
tuple2 = (3.14, 5**2, 10, 11, 12)

print(tuple1)
print(tuple2)
print(*tuple1)
print(*tuple2)

yList = [1, 5, 4, 1, 2, 6]
yTuple = (1, 5, 4, 1, 2, 6)
print(yList)
print(yTuple)
print(*yList)
print(*yTuple)
print(yList == yTuple)

#Section 2 - ARBITRARY ARGUMENT LISTS
print(average(5, 8, 14))
z = average(-1, 4, 5, -8)
print(z)
average(2, 10)
z = average(*yTuple)
print(z)

z = average(*yList)
print(z)

print(product(2, 4, 6))
z = product(-1, -1, -1, -3)
print(z)

#Section 3 - RETURNING MULTIPLE VALUES
fullName = getNames()
print(fullName)
print("First:", fullName[0])
print("Middle:", fullName[1])
print("Last:", fullName[2])

#Section 4 - TYPING IT TOGETHER
whole = (getMyStats(98, 97, 55, 82, 73, 88))
print(*whole[4])
print("Min:", whole[0])
print("Max:", whole[1])
print("Mean:", whole[2])
print("Median:", whole[3])