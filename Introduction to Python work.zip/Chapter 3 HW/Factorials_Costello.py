# -*- coding: utf-8 -*-
"""
Created on Fri Sep 13 15:29:49 2019

HW 3B #3.13 in Ch3 Exercises p.113

This script does factorial calculations on a non-negative integer.

@author: Benjamin Costello
"""

#Get the non-negative integer from the user.
number = int(input("Enter a non-negative integer: "))

#Compute and display the factorial.
factorial = 1
for i in range(1, number, + 1):
    factorial *= i
print("The factorial of", number, "is", factorial)