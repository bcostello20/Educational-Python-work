# -*- coding: utf-8 -*-
"""
Created on Wed Dec  4 09:57:25 2019

Lab7B_MoreOnDFs.py

This script focuses on Chapter7B Lab with more focus on DFs.

@author: Benjamin Costello
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("complaints.csv")

print("Printing List of the Columns")
print(df.columns)

print("\nPrinting First Few Rows")
print(df.head())

print("\nPrint the Dimensions")
print(df.ndim)
print(df.size)

print("\nPrint How Many Rows and Cols")
print(df.shape)

num_complaints = df.iloc[:, 1]
complaint_hours = df.iloc[:, 5]
complaints = num_complaints / complaint_hours * 1000
df["complaints_1000hrs"] = complaints
print(df)

print(df["complaints_1000hrs"].describe())

xBins = np.arange(-0.5, 6.59, 1)

#create the histogram
theHistogram = complaints.hist(grid = True, bins = xBins, edgecolor="black")
plt.title("Complaints 1000 Hrs") #set its title
plt.xlabel("Number of Complaints (Per 100 Hours Worked)")
plt.ylabel("Frequency")
plt.xticks(range(0, 8)) #Get a tick mark at every spot 1-7 on the x axis
plt.yticks(range(0, 20, 2)) #Get a tick mark at 0, 2, 4, ... on the y axis
plt.show() #show the histogram

#female data frame
criteria = (df["gender"] == 'F') #This creates a criteria comparing
                                 #gender in each row to 'F'
females = df[criteria] #Ths selects all rows from our data frame that meet our criteria

xBins = np.arange(-0.5, 10, 1)

#create female data histogram
theHistogram1 = females["complaints_1000hrs"].hist(grid = True, bins = xBins, edgecolor="black")
plt.title("Number of Complaints Against Female Physicians") #set its title
plt.xlabel("Number of Complaints (Per 100 Hours Worked)")
plt.ylabel("Frequency")
plt.xticks(range(0, 13)) #Get a tick mark at every spot 1-12 on the x axis
plt.yticks(range(0, 11)) #Get a tick mark at every spot 1-10, ... on the y axis
plt.show() #show the histogram
print(females["complaints_1000hrs"].describe())

#male data frame
criteria = (df["gender"] == 'M') #This creates a criteria comparing
                                 #gender in each row to 'M'
males = df[criteria] #Ths selects all rows from our data frame that meet our criteria

##create male data histogram
theHistogram2 = males["complaints_1000hrs"].hist(grid = True, bins = xBins, edgecolor="black")
plt.title("Number of Complaints Against Male Physicians") #set its title
plt.xlabel("Number of Complaints (Per 100 Hours Worked)")
plt.ylabel("Frequency")
plt.xticks(range(0, 13)) #Get a tick mark at every spot 1-7 on the x axis
plt.yticks(range(0, 11, 1)) #Get a tick mark at 0, 2, 4, ... on the y axis
plt.show() #show the histogram
print(males["complaints_1000hrs"].describe())

#Resident vs Non-Resident

#resident data frame
criteria = (df["residency"] == 'Y ')

residents = df[criteria]

#create residents histogram
theHistogram3 = residents["complaints_1000hrs"].hist(grid = True, bins = xBins, edgecolor="black")
plt.title("Number of Complaints From Residents") #set its title
plt.xlabel("Number of Complaints (Per 100 Hours Worked)")
plt.ylabel("Frequency")
plt.xticks(range(0, 13)) #Get a tick mark at every spot 1-7 on the x axis
plt.yticks(range(0, 11, 1)) #Get a tick mark at 0, 2, 4, ... on the y axis
plt.show() #show the histogram
print(residents["complaints_1000hrs"].describe())

#non-resident data frame
criteria = (df["residency"] == 'N ')

non_residents = df[criteria]

#create non-residents histogram
theHistogram4 = non_residents["complaints_1000hrs"].hist(grid = True, bins = xBins, edgecolor="black")
plt.title("Number of Complaints From Non-Residents") #set its title
plt.xlabel("Number of Complaints (Per 100 Hours Worked)")
plt.ylabel("Frequency")
plt.xticks(range(0, 13)) #Get a tick mark at every spot 1-7 on the x axis
plt.yticks(range(0, 11, 1)) #Get a tick mark at 0, 2, 4, ... on the y axis
plt.show() #show the histogram
print(non_residents["complaints_1000hrs"].describe())