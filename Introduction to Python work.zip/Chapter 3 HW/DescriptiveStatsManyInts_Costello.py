# -*- coding: utf-8 -*-
"""
Created on Sat Sep 14 15:36:19 2019

HW 3B #3.8 Ch3 p.113

This is a script that modifies Exercise 2.10, which will input any amount of integers, then display the sum,--
average, product, smallest and largest of those values. This utilizes a loop.

@author: Benjamin Costello
"""

#Variable declarations
current = 1
totalSum = current
totalProduct = current
counter = 0

#Input and processing
current = input("Enter an integer, z to end: ")
currentMin = current
currentMax = current
while (current != 'z'):
    totalSum += (int(current))
    counter += 1
    totalProduct *= (int(current))
    if (int(current)) < (int(currentMin)):
        currentMin = current
    if (int(current)) > (int(currentMax)):
        currentMax = current
    current = input("Enter an integer, z to end: ")
    
#Display the results
if current == 'z':
    print("The sum is:", totalSum)
    print("The average is:", totalSum / counter)
    print("The product is:", totalProduct)
    print("The smallest number is:", currentMin)
    print("The largest number is:", currentMax)