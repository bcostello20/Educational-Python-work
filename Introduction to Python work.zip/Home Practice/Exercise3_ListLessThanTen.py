 #The list
a = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]

#For loop to iterate through the list and find the numbers that are less than 5.
for item in a:
    if item < 5:
        b = [] #Create the new list
        b.append(item) #Add the numbers less than 5 into the new list.
        print(*b) #Print the contents of the new list.

#Ask the user for a number.
num = int(input("Enter a number: "))

for item in a:
    if item < num:
        c = [] #New list
        c.append(item) #Add numbers from list a, that are smaller than the user given number.
        print(*c) #Print the contents of c list.