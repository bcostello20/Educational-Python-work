"""
Primes.py
Given an integer input n, this program (for Lab 3D) lists which 
numbers from 1 to n are prime and furthermore shows
a factorization for any composite numbers.
@author Benjamin Costello
"""

#ASK THE USER FOR AN INTEGER - CALL IT n
n = int(input("Enter an integer: "))
#FOR EACH INTEGER FROM 2-n:
if n > 1:
   for i in range(2, n):
       if (n % i) == 0:
            print(n, "is a product.")
            break;
   else:
       print(n, "is a prime number.")
	#Loop over the integers less than n and see if any 
	#divide n.  As soon as one does, print n as a product 
	#(so as to prove n is not prime) and then break out of the
	#loop.
	
	#In the else loop of the loop (which would only be 
	#called if we did NOT break out of the loop, meaning that
	#n is indeed prime)  print that x must be prime.  