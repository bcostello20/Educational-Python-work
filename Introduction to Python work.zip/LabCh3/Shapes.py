# -*- coding: utf-8 -*-
"""
Created on Wed Sep 18 10:40:52 2019

LabCh3 3B Section 3.8 - For Loops

@author: Benjamin Costello
"""

#First triangle pattern
for row in range(1, 11):
    for col in range(1, row + 1):
        print('*', end="")
    print("\n")

#Second triangle pattern
for row2 in range(10, 0, -1):
    for col2 in range(1, row2 + 1):
        print('*', end="")
    print("\n")

#Third triangle pattern
for row3 in range(10, 0, -1):
    for j in range(10 - row3):
        print(end=" ")
    for col3 in range(1, row3 + 1):
        print('*', end="")
    print("\n")
    
#Fourth triangle pattern
for row4 in range(1, 11):
    for i in range(10 - row4):
        print(end=" ")
    for col4 in range(1, row4 + 1):
        print('*', end="")
    print("\n")

#Slash triangle pattern
x = int(input("How long should the triangle side be?: "))
n = 0

for i in range(n, x):
    if i == x - 1:
        print(" " * (int(x) - n) + "/" + "_" * (2*n) + "\ ")
    else:
        print(" " * (int(x) - n) + "/" + " " * (2*n) + "\ ")
    n += 1