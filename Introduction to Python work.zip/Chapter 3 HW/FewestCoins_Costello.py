# -*- coding: utf-8 -*-
"""
Created on Wed Sep 11 11:40:46 2019

@author: Benjamin Costello

This is a script that inputs a purchase price of a dollar or less for an item. It will determine--
the amount of change the cashier should give back to the purchaser. It will then display the--
change using the fewest number of pennies, nickels, dimes and quarters.

"""

#Get the purchase price from the user.
amount = int(input("Please enter an amount between 0-100: "))

#Calculate and display the results.
print("Your change is:")

print(amount//25, "quarters")
amount = amount%25
print(amount//10, "dimes")
amount = amount%10
print(amount//5, "nickels")
amount = amount%5
print(amount//1, "pennies")