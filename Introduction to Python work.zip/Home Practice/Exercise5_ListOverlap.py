import random

#Set up two lists of different length.
a = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]
b = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]

#Create a new empty list.
newList = []

#Check for common elements between the lists and add them to a new list.
for item in a:
    if item in b:
        newList.append(item)

#Display the new list.
print(newList)

#Generate two lists of random numbers but of different length.
c = [1, random.randrange(1, 30)]
d = [1, random.randrange(10, 40)]

#Another new list.
anotherList = []

for i in c:
    if i in d:
        anotherList.append(i)

#Display the list.
print(anotherList)