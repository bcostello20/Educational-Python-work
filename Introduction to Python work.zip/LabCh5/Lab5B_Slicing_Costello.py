# -*- coding: utf-8 -*-
"""
Created on Fri Nov  1 09:58:31 2019

Lab5B_Slicing_Costello.py

This script focuses on Chapter5B Lab which focuses on Slicing.

@author: Benjamin Costello
"""
def receiveList(aList, aList2):
    """Receives a list and returns a (possibly shorter) list containing only the unique
    values in sorted order."""
    aList.sort()
    newList = []
    newList2 = []
    for i in aList:
        if i != 8:
            newList.append(i)
    for j in aList2:
        if j != 'c':
            newList2.append(j)
    return newList, newList2

def isPalindrome(aString):
    """Takes a string and returns True if it's a palindrome and False otherwise."""
    newString = aString[::-1]
    if aString == newString:
        return True
    else:
        return False

#EXERCISE 5.5

#alphabet string
alphabet = "abcdefghijklmnopqrstuvwxyz"

firstHalf = alphabet[0:14]
firstHalf2 = alphabet[:14]

secondHalf = alphabet[14:26]
secondHalf2 = alphabet[14:]

everyFifthLetter = alphabet[2::5]

stringReversed = alphabet[::-1]

everyThirdLetterReversed = alphabet[::-3]

print(firstHalf)
print(firstHalf2)
print(secondHalf)
print(secondHalf2)
print(everyFifthLetter)
print(stringReversed)
print(everyThirdLetterReversed)

#EXERCISE 5.7
numberList = [3, 7, 1, 8, 5, 2, 10, 8, 4, 6]
stringList = ['a', 'b', 'c', 'c', 'd']
print(receiveList(numberList, stringList))

#EXERCISE 5.9
theString = str(input("Enter a word to see if it's a palindrome: "))
print(isPalindrome(theString))