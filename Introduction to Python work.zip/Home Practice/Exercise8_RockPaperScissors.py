import random

#The choices for the CPU player
choices = ["Rock", "Paper", "Scissors"]

tie = True
while (tie == True):

    #Display choices
    print("You may choose from: Rock, Paper, or Scissors.")

    #Get player 1's play
    player1 = input("Player 1 Play: ")

    #CPU player's play
    CPU = random.choice(choices)

    #Display CPU's choice
    print("CPU Play:", CPU)

    #Check if it's a tie
    if player1 == CPU:
        print("It's a tie!")

    #Check the cases of Rock and Scissors
    if player1 == "Rock" and CPU == "Scissors":
        print("Player 1 wins! Rock beats Scissors.")
        tie = False
    elif player1 == "Scissors" and CPU == "Rock":
        print("CPU wins! Rock beats Scissors.")
        tie = False

    #Check the cases of Scissors and Paper
    if player1 == "Scissors" and CPU == "Paper":
        print("Player 1 wins! Scissors beats Paper.")
        tie = False
    elif player1 == "Paper" and CPU == "Scissors":
        print("CPU wins! Scissors beats Paper.")
        tie = False

    #Check the cases of Paper and Rock
    if player1 == "Paper" and CPU == "Rock":
        print("Player 1 wins! Paper beats Rock.")
        tie = False
    elif player1 == "Rock" and CPU == "Paper":
        print("CPU wins! Paper beats Rock.")
        tie = False