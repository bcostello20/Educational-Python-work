name = input("Enter your name: ")
age = int(input("Enter your age: "))

year = (2019 - age) + 100

message = name +" will turn 100 years old in the year " + str(year) + "." + "\n"

print(message, sep="")

number = int(input("Enter a number: "))

print(message * number)