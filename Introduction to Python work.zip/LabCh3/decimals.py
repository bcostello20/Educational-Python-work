# -*- coding: utf-8 -*-
"""
Created on Mon Sep 30 10:16:32 2019

decimals.py

This script does the needed responses to Lab3F_DecimalType.pdf. Goes through examples of spacing--
followed by a full program which calculates and displays an amount of money at the end of each--
year in a bank account.

@author: Benjamin Costello
"""
from decimal import Decimal

a = 1325.48
b = 5.17
c = 328.48

print(f"{a:>7.2f}")
print(f"{b:>7.2f}")
print(f"{c:>7.2f}")

temperature = 98.6
print(f"{temperature:>.20f}")

temperature = Decimal("98.6")
print(f"{temperature:.20f}")

x = Decimal("10.5")
y = Decimal("2")
print(x+y)
print(x//y)
x *= y
print(x)
x %= 6
print(x)
print(type(x))

print(x**2)

#print(x**2.0) #commented this out, gives an error reequired by the lab

#------------------------------------------------------------------------------

#Get user input
principal = int(input("Enter the principal: "))
annInterestRate = int(input("Enter the annual interest rate (as a whole number): ")) / 100
numOfYears = int(input("Enter number of years the money has been invested: "))

for i in range(1, numOfYears + 1):
    amount = principal * (1 + annInterestRate) ** i
    print(f"{i:<5.0f}", f"{amount:>.2f}")