# coding: utf-8

#Benjamin Costello

grade = 85
if grade >= 60:
    print("Passed")
    
if grade >= 60:
     print("Passed")
    
if grade >= 60:
     print("Passed")
   print("Good job!") 
if 1:
    print("Nonzero values are True, so this will print")
    
if 0:
    print("Zero is False, so this will not print")
    
grade == 85
grade == 58
grade = 58
x == 85
grade = 85
if grade >= 60:
    print("Passed")
else:
    print("Failed")
    
grade = 57
if grade >= 60:
    print("Passed")
else:
    print("Failed")
    
grade = 99
if grade >= 60:
    print("Passed")
else:
    print("Failed")
    
grade = 87
if grade >= 60:
    result = ("Passed")
else:
    result = ("Failed")
    
result
result = ("Passed" if grade >= 60 else "Failed")
result
"Passed" if grade >= 60 else "Failed"
grade = 49
if grade >= 60:
    print("Passed")
else:
    print("Failed")
    print("You must take this course again.")
    
grade = 100
if grade >= 60:
    print("Passed")
else:
    print("Failed")
print("You must take this course again.")
    
grade = 77
if grade >= 90:
    print('A')
elif grade >= 80:
    print('B')
elif grade >= 70:
    print('C')
elif grade >= 60:
    print('D')
else:
    print('F')
    
product = 3
while product <= 50:
    product = product * 3
    
product
get_ipython().run_line_magic('save', 'Videos03_IfAndWhileExamples_Costello 1-33')
