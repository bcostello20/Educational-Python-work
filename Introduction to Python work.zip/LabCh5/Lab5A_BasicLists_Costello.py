# -*- coding: utf-8 -*-
"""
Created on Mon Oct 28 11:02:39 2019

Lab5A_BasicLists_Costello.py

This script focuses on Chapter4D Lab with a focus on basic lists and using the
enumerated and iterator techniques.

@author: Benjamin Costello
"""

def numLetters(words):
    """Uses the enumerate technique to print out the index of the word, the word,
    and how many letters are in the word."""
#    for i in range(0, len(words)):
#        print(f"{i}: {words[i]}", len(words[i]))
    for index, word in enumerate(words):
        print(f"{index}: {word}", len(words[index]))
        
def parityCheck(values):
    """Uses the iterator technique to return a list containing only "even" or "odd"
    which indicates if the number is even or odd."""
    
    theList = []
    
    for num in values:
        if num % 2 == 0:
            theList.append("even")
        else:
            theList.append("odd")
    return theList
        
#First call
numLetters(["Please", "Excuse", "My", "Dear", "Aunt", "Sally"])

print()

#Second call
numLetters(["The", "brown", "fox", "jumped", "over", "the", "fence"])

print()

#Third call
numLetters(["He", "sat", "down", "by", "the", "old", "tower", "to", "take", "a", "break"])

print()

#First call
print(parityCheck([0, -10, 15, 13, 12]))

print()

#Second call
print(parityCheck([1, -4, 11, 16, 17]))

print()

#Third call
print(parityCheck([2, 7, -14, 21, 8]))