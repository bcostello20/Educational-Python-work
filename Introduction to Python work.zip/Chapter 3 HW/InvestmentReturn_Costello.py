# -*- coding: utf-8 -*-
"""
Created on Fri Sep 13 15:54:13 2019

HW 3B Ch3 #3.10 p.113

This script reimplements Exercise 2.12 to use a loop that calculates and displays the amount of money you'll--
have each year at the ends of years 1 through 30.

@author: Benjamin Costello
"""
#Variables
startValue = 1000
annualRate = 0.07

#Compute and display money amounts after 10, 20, and 30 years.
print("\tORIGINAL EXERCISE:")
amount10 = startValue * (1 + annualRate) ** 10
print("You will have $", amount10, " after 10 years of investment.", sep="")

amount20 = startValue * (1 + annualRate) ** 20
print("You will have $", amount20, " after 20 years of investment.", sep="")

amount30 = startValue * (1 + annualRate) ** 30
print("You will have $", amount30, " after 30 years of investment.\n", sep="")

#------------------------------------------------------------------------------
#Using a loop
print("\tMODIFIED EXERCISE:")
for number in range(1, 31):
    amount = startValue * (1 + annualRate) ** number
    print("You will have $", amount, " after ", number, " years of investment.", sep="")