# coding: utf-8
print('hello world!')
('x =', x)
x = 2
y = 3
print ('x =', x)
print('Value of', x, '+', x, 'is', (x+x))
print('x = ')
print((x+y), '=', (y+x))
get_ipython().run_line_magic('clear', '')
clear
print ("We\n\thave\n\t\toff\n\t\t\tMonday!\n\t\t\t\tYay!")
x = "Save the file at C:\\\\MyFolder\\MySubfolder"
print (x)
x = "Mary O\'Bono screamed, \"Run Spot! Run!!\" and then started running as well"
print (x)
27.5 + 2
27.5 -2
27.5 * 2
27.5 / 2
27.5 // 2
27.5 ** 2
27.5 ** 1/2
27.5 ** (1/2)
if x >= 5:
    print (x, 'is at least 5!')
    print ('The square of', x, 'must therefore be at least 25!')
    x = 7
    
x = 7
if x >= 5:
    print (x, 'is at least 5!')
    print ('The square of', x, 'must therefore be at least 25!')
    end if
x = 7
if x >= 5:
    print (x, 'is at least 5!')
    print ('The square of', x, 'must therefore be at least 25!')
    
x = 3
if x >= 5:
    print (x, 'is at least 5!')
    print ('The square of', x, 'must therefore be at least 25!')
    
grade = 91
if grade >= 90:
    print ("Congratulations! Your grade of 91 earns you an A in this course!")
    
1024 % 4
17 % 10
get_ipython().run_line_magic('save', 'LabCh2InteractiveMode_Costello')
