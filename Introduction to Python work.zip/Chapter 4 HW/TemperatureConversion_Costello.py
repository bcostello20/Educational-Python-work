# -*- coding: utf-8 -*-
"""
Created on Fri Oct  4 11:26:19 2019

TemperatureConversion_Costello.py

This script uses a fahrenheit function that returns the fahrenheit equivilent of a Celsius--
temperature.

@author: Benjamin Costello
"""

#Method Definitions
def fahrenheit(celsius):
    """Converts a celsius temperature to fahrenheit."""
    fahrenheitTemp = (9 / 5) * celsius + 32
    return fahrenheitTemp

#Table header
print("Celsius\t\tFahrenheit") 

#Calculate fahrenheit for temperatures 0-100
for temp in range(0, 101):
    f = fahrenheit(temp)
    print(f"{temp:>7.1f}\t\t{f:>10.1f}")
    
