# -*- coding: utf-8 -*-
"""
Created on Fri Aug 30 11:18:31 2019

@author: Benjamin Costello
"""

#Get the five-digit integer from the user
theNumber = input("Enter a five-digit integer: ")

#Print the five-digit integer separated by digits
print(theNumber[0], "", theNumber[1], "", theNumber[2], "", theNumber[3], "", theNumber[4])