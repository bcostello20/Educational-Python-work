# -*- coding: utf-8 -*-
"""
Created on Wed Sep  4 10:52:29 2019

LabCh2_FirstPythonScript_Costello.py

This file contains all of the code requested in the Ch 2 Lab.

@author: Benjamin Costello

Lab 1 - CS 215
"""

#Calculate geometric values of a circle.

pi = 3.1415926

radius = float(input("Enter a radius: "))

diameter = 2 * radius
circumference = 2 * pi * radius
area = pi * radius ** 2

print ("Here are the calculations for a circle with radius", radius,":")
print("\tThe diamater is: ", diameter)
print("\tThe circumference is: ", circumference)
print("\tThe area is: ", area)

#Determine the parity of an integer.

x = int(input("Enter a number: "))

if x % 2 == 0:
    print("You entered", x, "which is even.")
if x % 2 != 0:
    print("You entered", x, "which is odd.")

print("\n")
#Create a table of squares and cubes.
print("number" "\tsquare" "\tcube")
print("0" "\t0" "\t0\n" "1" "\t1" "\t1\n" "2" "\t4" "\t8\n" "3" "\t9" "\t27\n" "4" "\t16" "\t64")
