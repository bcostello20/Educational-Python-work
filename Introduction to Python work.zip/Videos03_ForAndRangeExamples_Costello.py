# coding: utf-8

#Benjamin Costello

for character in "Programming":
    print(character, end="  ")
    
print(10, 20, 30, sep=", ")
total = 0
for number in [2, -3, 0, 17, 9]:
    total = total + number
    
total
for counter in range(10):
    print(counter, end=" ")
    
total = 0
for number in [1, 2, 3, 4, 5]:
    total += number
    
total
for number in range(5, 10):
    print(number, end=" ")
    
for number in range(0, 10, 2):
    print(number, end=" ")
    
for number in range(10, 0, -2):
    print(number, end=" ")
    
get_ipython().run_line_magic('save', 'Videos03_ForAndRangeExamples_Costello 1-14')
