#Get user to enter a number.
number = int(input("Enter a number: "))

#Check to see whether the number is even or odd based on a MOD of 2.
if number % 2 == 0:
    print("The number", number, "is even!")
else:
    print("The number", number, "is odd.")

#Check if the number is a multiple of 4.
if number % 4 == 0:
    print(number, "is a multiple of 4.")

#Ask the user for two numbers
num = int(input("Enter a number to check: "))
check = int(input("Enter a number to divide by: "))

#See if num divides evenly into check
if num % check == 0:
    print(num, "divides evenly into", check)
else:
    print(num, "does not divide evenly into", check)