#Ask the user for a string.
theString = str(input("Enter a string: "))

#Reverse the string and assign to a new variable.
reverse = theString[::-1]

#Display the reversed string
print(reverse)

#Check if the string is the same reversed.
if theString == reverse:
    print("This string is a palindrome.")
else:
    print("This string is not a palindrome.")