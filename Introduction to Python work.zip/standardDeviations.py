# -*- coding: utf-8 -*-
"""
Created on Wed Oct 16 09:59:40 2019

@author: Student
"""

import statistics as stats

def printSDs(data):
    sampleSD = stats.stdev(data)
    popSD = stats.pstdev(data)
    print(f"Sample SD: {sampleSD}")
    print(f"Population SD: {popSD}")
    print("*******************")
    
dataA = [63, 68, 71, 78, 80]
dataB = [10, 85, 86, 89, 90]
dataC = [20, 70, 80, 90, 100]

printSDs(dataA)
printSDs(dataB)
printSDs(dataC)