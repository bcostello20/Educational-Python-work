import random as rand

def hareMovement():
    """This function allows us to determine how many spaces the hare moves for
       each tick on the clock."""
    #Generate rand num between 1-10
    randNum = rand.randrange(1,11)
    #print(randNum)
    #if number is between 1-2, hare does not move, 20% chance
    if (randNum > 0 and randNum < 3):
         movement = 0
    #if number is between 3-4, hare moves 9; 20% chance     
    elif(randNum > 2 and randNum < 5):
        movement = 9
    #if number is 5, hare goes back 12; 10% chance
    elif(randNum == 5):
        movement = -12
    #if number is between 6-8, hare moves forward 1, 30% chance
    elif(randNum > 5 and randNum < 9):
        movement = 1
    #if number is between 9-10, hare moves forward 2
    else:
        movement = -2
    return movement

def tortoiseMovement():
    """This function allows us to determine how many spaces the tortouise moves
       for each tick on the clock."""
       #Generate random  number between 1-10
    randNum = rand.randrange(1,11)
    #print(randNum)
       #if the number is between 1-5, tortoise moves 5; 50% chance
    if(randNum > 0 and randNum < 6):
        movement = 3
    #if the number is between 6-7, tortoise moves back 6; 20% chance
    elif(randNum > 5 and randNum < 8):
        movement = -3
    #if the number is between 8-10, tortoise moves forward 1; 30% chance    
    else:
        movement = 1 
    return movement        


def raceTrack(tortoiseP, hareP):
    """This function creates the race track for our viewing pleasure. It creates
    a 70-dashed line and displays the location of the hare(H) and the tortoise(T).
    """
    
    for i in range(1, 71):
        if i == tortoiseP and i == hareP:
    for e in range(i, 71):
        print("OUCH!!!", sep="", end="")
        break
        elif i == tortoiseP:
            print('T',sep="",end ="")
        elif i == hareP:
            print('H', sep="", end="")
        else:
            print("-",sep="", end="")
       
        #print(i, end="")
           

#This number is set to 1, when either of the competitors wins it gets changed 
#to 2. If they tie it remains 1. If they tie they race again
winConditionNum = 1


#while loop to go until the race is not a tie
while(winConditionNum == 1):
    #starting positions for competitors, will be used to keep track of loaction
    #throughout the race
    tortoise = 1
    hare = 1
    #    
    #The Race begins
    print("BANG!!!!")
    print("AND THEY'RE OFF!!!!")
    #    
    #the clock
    clock = 0
    #tortoise = 70
    #hare = 70
    #clock = 0    
    
    while(tortoise < 70 and hare < 70):
        #Updates clock
        clock += 1
        #updates tortoise movement
        tortoise += tortoiseMovement()
        #makes sure that the tortoise does not go below the starting line
        if tortoise < 1:
            tortoise = 1
        #("T: ",tortoise)
        #updates hare movement
        hare += hareMovement()
        #Makes sure the hare does not go below the starting line
        if hare < 1:
            hare = 1
        #print("H:",hare)
        raceTrack(tortoise, hare)
        print("\n")
    
    #Check to see if tortoise or hare won or they tied
    if tortoise == hare:
        print("It's a tie.")
    if tortoise > hare:
        print("TORTOISE WINS!!! YAY!!!")
        winConditionNum = 2
    if hare > tortoise:
        print("Hare wins. Yuch.")
        winConditionNum = 2
    
    print("TIME ELAPSED =", clock)