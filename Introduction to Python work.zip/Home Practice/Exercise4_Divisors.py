#Ask the user for a number
number = int(input("Enter a number: "))

#Create a range from 1 to user's number
x = range(1, number + 1)

#Create the list
theList = []

#Iterate through the numbers up to the user's number that divide evenly and add it to the list.
for num in x:
    if number % num == 0:
        theList.append(num)

#Display the list of numbers.
print(theList)