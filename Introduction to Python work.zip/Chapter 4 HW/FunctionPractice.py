# -*- coding: utf-8 -*-
"""
Created on Fri Oct 11 14:43:36 2019

FunctionPractice.py

This script contains two functions:
    circleGeometry - that takes in a radius and returns both the area of the circle and the circumference of-- 
    a circle.
    letterMultiplier - that takes in an arbitrary series of alternating letters/numbers and multiplies the--
    letters that are output.

@author: Benjamin Costello
"""

def circleGeometry(radius):
    """Takes in a radius and returns both the area and circumference of the circle."""
    area = 3.14159 * radius ** 2
    circumference = 2 * 3.14159 * radius
    return (area, circumference)

def letterMultiplier(*args):
    """Takes in an arbitrary series of alternating letters/numbers and multiplies the letter by the following value."""
    theString = ""
    for character in args:
        if type(character) == int:
            theString += theString[-1] * (int(character) - 1)
        else:
            theString += character
    return theString
    
#Get a radius from the user.
radius = int(input("Enter a radius: "))

#Display the area and circumference.
result = circleGeometry(radius)
print("Area:", result[0])
print("Circumference", result[1])

#letterMultiplier inputs
print(letterMultiplier("L", 4, "H", 8))
print(letterMultiplier("L", 4, "p", 3, "j", 2))