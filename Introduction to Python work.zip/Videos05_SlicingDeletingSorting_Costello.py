# coding: utf-8

#Benjamin Costello

numbers = [2, 3, 5, 7, 11, 13, 17, 19]
numbers[2:6]
numbers[:6]
numbers[0:6]
numbers[6:]
numbers[6:len(numbers)]
numbers[:]
numbers[::2]
numbers[::-1]
numbers[-1:-9:-1]
numbers[0:3] = ["two", "three", "five"]
numbers
numbers[0:3] = []
numbers
numbers = [2, 3, 5, 7, 11, 13, 17, 19]
numbers[::2] = [100, 100, 100, 100]
numbers
id(numbers)
numbers[:] = []
numbers
id(numbers)
numbers = []
numbers
id(numbers)
numbers = list(range(10))
numbers
del numbers[-1]
numbers
del numbers[0:2]
numbers
del numbers[::2]
numbers
del numbers[:]
numbers
del numbers
numbers
numbers = [10, 3, 7, 1, 9, 4, 2, 8, 5, 6]
numbers.sort()
numbers
numbers = [10, 3, 7, 1, 9, 4, 2, 8, 5, 6]
numbers.sort(reverse=True)
numbers
numbers = [10, 3, 7, 1, 9, 4, 2, 8, 5, 6]
ascending_numbers = sorted(numbers)
ascending_numbers
numbers
letters = "fadgchjebi"
ascending_letters = sorted(letters)
ascending_letters
letters
colors = ("red", "orange", "yellow", "green", "blue")
ascending_colors = sorted(colors)
ascending_colors
colors
sorted(colors, reversed=True)
sorted(colors, reverse=True)
get_ipython().run_line_magic('save', 'Videos05_SlicingDeletingSorting_Costello 1-57')
