"""
Lab3B_IfAndWhile.py

This program practices if statements (if-else, if-elif, if-elif-else) and 
while loops while validating input and looking for patterns.

Benjamin Costello
"""

############################################################################
#Task 1 
############################################################################

#Input Validation Program

x = int(input("Enter 1 or 2 please: "))

counter = 1

while x != 1 and x != 2:  #check to see if x is neither 1 nor 2.
    x = int(input("Enter 1 or 2 please: ")) #Re-ask for a 1 or 2.
    counter = counter + 1
    
print("\nFINALLY! It took you", counter, "times - geesh!")


############################################################################
#Task 1 Continued - Ask the user for an even integer
############################################################################
    
evenNum = int(input("Enter an even number: "))

while evenNum % 2 != 0:
    evenNum = int(input("Enter an even number: "))
    counter + 1
    
print("\nFINALLY! It took you", counter, "times to remember what an even number is!")
############################################################################
#Task 2 - Using the counter to do math
############################################################################

#Ask the user for how many rows.
numRows = int(input("Enter an how many rows you'd like to see: "))

#Set the counter to a starting value.
counter = 0

#print the header
print("number\tsquare\tcube") 

#Use a loop to print out the rest of the rows.
while (counter < numRows):
    print(counter,"\t",counter ** 2,"\t",counter ** 3)
    counter = counter + 1


############################################################################
#Task 3 - Using the coutner to do math
############################################################################


#Get input
x = input("Input an integer: ")



#The len(string) function returns the length of a string

n = len(x) #Look at your lab handout!  I want you to type it to remember it.



#HINT:  A line of code goes here.  What type of variable is x?

y = int(x)



#Set your counter

counter = n




while (counter > 0):
    
    
    #what to divide by
    
    divisor = 10 ** (counter - 1)
    
    
    
    #Get the leftmost digit
    
    leftMostDigit = y // divisor
    
    

    #print the leftmost digit
    
    print(leftMostDigit, end =" ")
    
    

    #Remove the leftmost digit
    
    y = y % divisor
    
    

    #update the counter as needed.
    
    counter = counter - 1
    
    
############################################################################
#Task 4 - Age Classification
############################################################################

age = int(input("Enter a person's age: "))

if age <= 1:
    print("He or she is an infant.")
elif age > 1 and age < 13:
    print("He or she is a child.")
elif age >= 13 and age < 20:
    print("He or she is a teenager.")
else:
    print("He or she is an adult.")