# coding: utf-8
#Benjamin Costello
import random
for roll in range(10):
    print(random.randrange(1, 7), end=" ")
    
for roll in range(10):
    print(random.randrange(1, 7), end=" ")
    
get_ipython().run_line_magic('run', 'fig04_01.py')
random.seed(32)
for roll in range(10):
    print(random.randrange(1, 7), end=" ")
    
for roll in range(10):
    print(random.randrange(1, 7), end=" ")
    
random.seed(32)
for roll in range(10):
    print(random.randrange(1, 7), end=" ")
    
import math
get_ipython().run_line_magic('pinfo', 'math.pow')
math.sqrt(900)
math.fabs(-10)
from math import ceil, floor
ceil(10.3)
floor(10.7)
e = "hello"
from math import *
e
import statistics as stats
grade = [85, 93, 45, 87, 93]
stats.mean(grades)
stats.mean(grade)
x = 7
def access_global():
    print("x printed from global scope:", x)
    
access_global()
def try_to_modify_global():
    x = 3.5
    print("x printed from try_to_modify_global:", x)
    
try_to_modify_global()
x
def modify_global():
    global x
    x = "hello"
    print("x printed from modify_global:", x)
    
modify_global()
x
sum = 10 + 5
sum
sum([10, 5])
type(sum)
get_ipython().run_line_magic('save', 'Videos04_MoreOnFunctions_Costello 1-37')
