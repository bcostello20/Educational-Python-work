# -*- coding: utf-8 -*-
"""
Created on Fri Aug 30 10:56:57 2019

@author: Benjamin Costello
"""

#Get three integers from the user
num1 = int(input("Enter first integer: "))
num2 = int(input("Enter second integer: "))
num3 = int(input("Enter third integer: "))

#Get and display the sum of all three integers
sum = num1 + num2 + num3
print("The sum is: " , sum)

#Get and display the average
average = sum / 3
print("The average is: " , average)

#Get and display the product
product  = num1 * num2 * num3
print("The product is: " , product)

#Get and display the smallest integer
smallest = num1

if num2 < smallest:
    smallest = num2
if num3 < smallest:
    smallest = num3

print("The smallest integer is: " , smallest)

#Get and display the largest integer
largest = num1

if num2 > largest:
    largest = num2
if num3 > largest:
    largest = num3
    
print("The largest integer is: " , largest)