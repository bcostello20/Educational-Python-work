# -*- coding: utf-8 -*-
"""
FunctionsWithDefaultAndNone.py 
Lab Ch 4B: In this file we learn how to use default parameter values and 
we learn more about returning None. 
@author: Your Name
"""

def sillyFunction(x = -1):
    '''This function is NONEsense.'''
    if 1<x<9:
        return x**2
    elif x >= 9:
        return x**0.5
    
def rectangleArea(length, width = 10):
    area = length * width
    return area
    
y = sillyFunction(3)
print (f"output when 3 is passed in: {y}")

y = sillyFunction(9)
print (f"output when 9 is passed in: {y}")

y = sillyFunction(16)
print (f"output when 16 is passed in: {y}")

y = sillyFunction(-1)
print (f"output when -1 is passed in: {y}")


#Ask the user for input
#userInput = int(input("Enter a number for silly Function: "))
number = int(input("Enter a number: "))
y = sillyFunction(number)

if y == None:
    print("Silly Function returned None.")
else:
    print("Silly Function returned Something meaningful.")

y = sillyFunction()
print(f"output when no parameter is passed in: {y}")

#rectangleArea function work
y = rectangleArea(2, 3)
print(f"output when 2, 3 is passed in: {y}")
y = rectangleArea(3, 2)
print(f"output when 3, 2 is passed in: {y}")
y = rectangleArea(2)
print(f"output when 2 is passed in: {y}")
y = rectangleArea(width = 2)
print(f"output when width = 2 is passed in: {y}")
y = rectangleArea()
print(f"output when nothing is passed in: {y}")

#pow call work
y = pow(2, 3)
print(f"output of pow(2,3) is: {y}")
y = pow(2)
print(f"output of pow(2) is: {y}")
y = pow(2, 3, 5)
print(f"output of pow(2,3,5) is: {y}")
y = pow(4, 2, 7)
print(f"output of pow(4,2,7) is: {y}")


print("a", "b", "c", sep="-", end="***")
print("d", "e", sep="...", end="!!")