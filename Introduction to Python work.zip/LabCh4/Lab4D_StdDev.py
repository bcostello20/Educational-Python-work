# -*- coding: utf-8 -*-
"""
Created on Mon Oct 21 10:20:05 2019

Lab4D_StdDev.py

This script focuses on Chatper4D Lab with a focus on analyzing std deviations.

@author: Benjamin Costello
"""

import statistics as stats

def basicStats(data):
    """Takes in a list of values called data and prints the min, max, mean, median and
    standard deviation of the data. Returns a tuple of those values after printing."""
    minimum = min(data)
    maximum = max(data)
    mean = stats.mean(data)
    median = stats.median(data)
    stdDeviation = stats.stdev(data)
    tuple1 = minimum, maximum, mean, median, stdDeviation
    print("Minimum:", tuple1[0])
    print("Maximum:", tuple1[1])
    print("Mean:", tuple1[2])
    print("Median:", tuple1[3])
    print("Standard Deviation:", tuple1[4])
    return tuple1

def printIntervals(data, aMean, aStdDeviation, isApproxNormal = True):
    """Calculates the intervals corresponding to 1/2/3 SDs around the mean and prints 
    the ESTIMATED corresponding percentage of data."""
    
    if isApproxNormal:
        x = ["~68", "~95", "~99.7", "~0.3"]
        print("Per Empirical Guidelines:")
    else:
        x = [">=0", ">=75", ">=89", "<=11"]
        print("Per Cheyshev's:")
    
    left1 = aMean - aStdDeviation
    right1 = aMean + aStdDeviation
    left2 = aMean - 2 * aStdDeviation
    right2 = aMean + 2 * aStdDeviation
    left3 = aMean - 3 * aStdDeviation
    right3 = aMean + 3 * aStdDeviation
    
    #Exact percentages
    count1 = 0
    count2 = 0
    count3 = 0
    for value in data:
        if left1 <= value <= right1:
            count1 += 1
        if left2 <= value <= right2:
            count2 += 1
        if left3 <= value <= right3:
            count3 += 1
            
    print("EXACT:", count1/len(data) * 100, "ESTIMATED:", x[0])
    print("EXACT:", count2/len(data) * 100, "ESTIMATED:", x[1])
    print("EXACT:", count3/len(data) * 100, "ESTIMATED:", x[2])
    print("AMOUNT OUTSIDE 3 STANDARD DEVIATIONS:", 100 - count3/len(data) * 100, x[3])
    
def zscore(aValue, anotherMean, anotherStdDeviation):
    """Takes in a vaue, mean, and a standard deviation and returns the zscore of the
    value."""
    zscore = (aValue - anotherMean) / anotherStdDeviation
    return zscore

dailyChanges = [1, -4, 5, -8, -3, 14, -13, 8, 4, -4, -9, -11, -3, 11, -9, 5, -11, 7, 
                5, -15, 6, 11, -12, -2, 0, -4, 5, 3, 2, 11, 5, -1, 5, 3, -1, 2, -3, 0, 
                1, -7, -11, 0, 7, 0, -4, -5, 12, -1, 3, 2, -1, -2, 2, -10, -10, 8, 7, 
                -6, -9, -1, 1, 10, -5, 4, 5, 1, -10, -3, -2, 5, 1, -4, 1, 1, 3, 9, 6, 
                -1, -8, 5, -27, 10, -1, -8, -3, -5, 6, 14, 13, -25, -8, -3, 14, 2, 7, 
                -3, 4, 1, -10, 4, 7, -5, -7, -1, -2, -7, -5, 3, 16, 8, -2, -14, -2, 7, 
                -4, -4, 12, 0, -10, -5, -2, 1, -6, -9, 14, 0, 1, -5, -9, -3, 8, -2, 17,
                -4, -4, 0, -2, -16, 8, 6, -10, -1, 13, 0, -6, 3, 11, -14, -6, -3]

dailyChangesTrimmed = [1, -4, 5, -8, -3, 14, -13, 8, 4, -4, -9, -11, -3, 11, -9, 5, -11, 7, 
                5, -15, 6, 11, -12, -2, 0, -4, 5, 3, 2, 11, 5, -1, 5, 3, -1, 2, -3, 0, 
                1, -7, -11, 0, 7, 0, -4, -5, 12, -1, 3, 2, -1, -2, 2, -10, -10, 8, 7, 
                -6, -9, -1, 1, 10, -5, 4, 5, 1, -10, -3, -2, 5, 1, -4, 1, 1, 3, 9, 6, 
                -1, -8, 5, 10, -1, -8, -3, -5, 6, 14, 13, -8, -3, 14, 2, 7, 
                -3, 4, 1, -10, 4, 7, -5, -7, -1, -2, -7, -5, 3, 16, 8, -2, -14, -2, 7, 
                -4, -4, 12, 0, -10, -5, -2, 1, -6, -9, 14, 0, 1, -5, -9, -3, 8, -2, 17,
                -4, -4, 0, -2, -16, 8, 6, -10, -1, 13, 0, -6, 3, 11, -14, -6, -3]

print("Daily Changes:")
num = basicStats(dailyChanges)
print()
print("Daily Changes Trimmed:")
num = basicStats(dailyChangesTrimmed)
print()
theMean = num[2]
theStdDeviation = num[4]
printIntervals(dailyChanges, theMean, theStdDeviation)
print(zscore(-25, theMean, theStdDeviation))
print(zscore(-27, theMean, theStdDeviation))