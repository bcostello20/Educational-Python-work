# -*- coding: utf-8 -*-
"""
Created on Fri Sep 13 10:22:36 2019

LabCh3A2_Craps

This simulates the game of Craps. The player must roll a 7 or 11 to win. If the player rolls a 2,--
3, or 12 he/she loses. If the player does not roll a winning number but neither a losing number--
they player rolls again until they get their point number to win.

@author: Benjamin Costello
"""

import random

#Set the rolls
die1 = random.randrange(1,6)
die2 = random.randrange(1,6)

#Other variables
sumDie = die1 + die2
point = 0

#Check the sum
if (sumDie == 7 or sumDie == 11):
    print("A sum of", sumDie,"!","You win on the first roll!!")
elif (sumDie == 2 or sumDie == 3 or sumDie == 12):
    print("A sum of", sumDie,"!","You lose on the first roll!!")
else:
    point = sumDie #Rolled number (sumDie) becomes the point.
    print("A sum of", sumDie,", you have to get a sum of", sumDie, "before a sum of 7 to win.")
    
    #Keep rolling till the user rolls point or 7.
    die1 = random.randrange(1,6)
    die2 = random.randrange(1,6)
    newSumDie = die1 + die2
    
    while (newSumDie != point and newSumDie != 7):
        print("Rolling again...")
        die1 = random.randrange(1,6)
        die2 = random.randrange(1,6)
        newSumDie = die1 + die2
    
    if (newSumDie == point):
        print("A sum of", newSumDie,"!","You win!!")
    else:
        print("You lose.")