import random

def tortoise():
    movement = 0
    number = random.randrange(1, 11)
    if number == 1 or number == 2:
        movement = 3
    if number == 3 or number == 4:
        movement = 3
    if number == 5:
        movement = 3
    if number == 6 or number == 7:
        movement = -6
    if number == 8 or number == 9 or number == 10:
        movement = 1
    return movement

def hare():
    movement = 0
    number = random.randrange(1, 11)
    if number == 1 or number == 2:
        movement = 0
    if number == 3 or number == 4:
        movement = 9
    if number == 5:
        movement = -12
    if number == 6 or number == 7 or number == 8:
        movement = 1
    if number == 9 or number == 10:
        movement = -2
    return movement

def raceTrack(Position1, Position2):
    for i in range(0, 71):
        if i == Position1:
            print('H')
        if i == Position2:
            print('T')
        else:
            print("-")
        if Position1 == Position2:
            print("OUCH!!!")

print("BANG !!!!!")
print("AND THEY'RE OFF !!!!!")

startingGate = 1
Position1 = startingGate
Position2 = startingGate

counter = 0

while (tortoise or hare < 70):
    counter += 1
    tortoise()
    hare()
    Position1 += hare()
    Position2 += tortoise()

if Position1 > Position2:
    print("Hare wins. Yuch.")
if Position2 > Position1:
    print("TORTOISE WINS!!! YAY!!!")
if Position1 == Position2:
    print("It’s a tie.")

raceTrack(Position1, Position2)

print("TIME ELAPSED =", counter)