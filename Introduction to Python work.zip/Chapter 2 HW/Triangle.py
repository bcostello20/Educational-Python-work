# -*- coding: utf-8 -*-
"""
Created on Sun Sep  1 15:56:32 2019

@author: Benjamin Costello
"""

#Print out the triangle shape
print("     /""\\""\n""    /""  \\""\n""   /""    \\""\n""  /""      \\""\n"" /""        \\""\n""/""__________""\\")